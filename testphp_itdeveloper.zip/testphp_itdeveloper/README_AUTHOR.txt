Created by Lagsya Akrama

Do not include .env or vendor folder when pushing to GitHub.